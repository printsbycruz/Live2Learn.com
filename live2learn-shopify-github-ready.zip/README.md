# Live2Learn Shopify Theme

A clean, minimal Shopify Online Store 2.0 theme designed for the first Live2Learn hat drop.

## Upload to Shopify
1. Download `live2learn-shopify-theme.zip`.
2. In Shopify admin, open **Online Store → Themes**.
3. Under Draft themes, choose **Import theme → Upload zip file**.
4. Upload the ZIP and click **Customize**.
5. Add your hero image, collection, product photos, menus, logo, story image, and Instagram link.
6. Preview the store before publishing.

## GitHub
Create a new repository named `live2learn-shopify-theme`, unzip the theme, and upload the folders and files from the theme root.
